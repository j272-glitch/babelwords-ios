# VAST WebView Container for Android

A native Android WebView container with built-in VAST video ad support that **bypasses WebView restrictions**.

## Architecture

```
┌──────────────────────────────────────────────────┐
│                 Android App                      │
│                                                  │
│  ┌────────────────────────────────────────────┐  │
│  │              WebView                       │  │
│  │           (your web app)                   │  │
│  │                                            │  │
│  │   NativeAdBridge.playVAST(url) ───────────┼──┼──► Kotlin Bridge
│  │                                            │  │         │
│  └────────────────────────────────────────────┘  │         │
│                                                  │    OkHttp (native)
│  ┌────────────────────────────────────────────┐  │         │
│  │         ExoPlayer Overlay                  │◄─┼─────────┘
│  │      (native video playback)               │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
└──────────────────────────────────────────────────┘
```

## Key Components

| File | Purpose |
|------|---------|
| `MainActivity.kt` | WebView + ad overlay + JS bridge |
| `VASTAdManager.kt` | Native VAST fetch/play/tracking |
| `VASTParser.kt` | XML parser for VAST responses |

## Why This Works

**WebView restrictions only affect:**
- Requests made inside WebView
- JavaScript fetch/XHR calls

**Native Kotlin bypasses all of this:**
- `OkHttp` for VAST fetch → Not WebView
- `XmlPullParser` for VAST parsing → Not WebView  
- `ExoPlayer` for video playback → Not WebView
- `OkHttp` for tracking pixels → Not WebView

## Setup

1. Open project in Android Studio
2. Update the web app URL in `MainActivity.kt`:
   ```kotlin
   private val webAppUrl = "https://linguagt.com"
   ```
3. Sync Gradle
4. Build and run

## Web App Integration

**Same JavaScript API as iOS!**

### Check if Bridge is Available

```javascript
if (window.NativeAdBridge && window.NativeAdBridge.isAvailable()) {
    // Running in native container (iOS or Android)
} else {
    // Web fallback
}
```

### Play a VAST Ad

```javascript
// Listen for ad events
window.NativeAdBridge.onAdEvent = function(event) {
    switch (event.event) {
        case 'adStarted':
            console.log('Ad duration:', event.duration);
            break;
        case 'adProgress':
            console.log('Progress:', event.progress);
            break;
        case 'adEnded':
            console.log('Reason:', event.reason); // 'completed', 'skipped', 'cancelled'
            break;
        case 'adError':
            console.error('Error:', event.error);
            break;
    }
};

// Request the ad
window.NativeAdBridge.playVAST('https://your-vast-endpoint.com/ad.xml', {
    skipOffset: 5  // Allow skip after 5 seconds
});
```

### Preload an Ad

```javascript
window.NativeAdBridge.preloadVAST('https://your-vast-endpoint.com/ad.xml');
```

### Cancel Current Ad

```javascript
window.NativeAdBridge.cancelAd();
```

## Cross-Platform Compatibility

The JavaScript API is identical between iOS and Android:

| Method | iOS (Swift) | Android (Kotlin) |
|--------|-------------|------------------|
| `playVAST(url, options)` | ✅ | ✅ |
| `preloadVAST(url)` | ✅ | ✅ |
| `cancelAd()` | ✅ | ✅ |
| `isAvailable()` | ✅ | ✅ |
| `onAdEvent` callback | ✅ | ✅ |

Your web app code works on both platforms without changes:

```javascript
// Works on both iOS and Android
if (window.NativeAdBridge?.isAvailable()) {
    window.NativeAdBridge.playVAST(vastUrl);
}
```

## Dependencies

- **OkHttp 4.12** - HTTP client (native networking)
- **Media3 ExoPlayer 1.2** - Video playback
- **Kotlin Coroutines** - Async operations

## VAST Features Supported

- ✅ Inline ads
- ✅ Wrapper/redirect VAST
- ✅ Multiple media files (selects best quality)
- ✅ Tracking events (impression, start, quartiles, complete, skip)
- ✅ Click tracking
- ✅ Skippable ads with countdown
- ✅ Preloading

## Building

### Debug
```bash
./gradlew assembleDebug
```

### Release
```bash
./gradlew assembleRelease
```

APK will be in `app/build/outputs/apk/`

## Customization

### Change Skip Offset

In `VASTAdManager.kt`:
```kotlin
private var skipOffsetSeconds = 5  // Change default
```

Or per-ad from JavaScript:
```javascript
window.NativeAdBridge.playVAST(url, { skipOffset: 10 });
```

### Modify Ad Overlay UI

Edit `res/layout/activity_main.xml`

### Add More Bridge Methods

1. Add `@JavascriptInterface` method in `MainActivity.kt` → `AdBridge`
2. Add JavaScript method in `injectBridgeScript()`

## Troubleshooting

### Ads not loading
- Check Logcat for `VASTAdManager` logs
- Verify VAST URL is accessible
- Check `android:usesCleartextTraffic="true"` in manifest (for HTTP URLs)

### Video not playing
- Verify media file URL is valid MP4
- Check ExoPlayer errors in Logcat
- Ensure device has network access

### Bridge not working
- Check that `@JavascriptInterface` annotation is present
- Verify ProGuard rules keep the bridge class
- Check Logcat for JavaScript errors

## Project Structure

```
app/
├── src/main/
│   ├── java/com/linguavibe/vastcontainer/
│   │   ├── MainActivity.kt      # Main activity + bridge
│   │   ├── VASTAdManager.kt     # Ad management
│   │   └── VASTParser.kt        # XML parsing
│   ├── res/
│   │   ├── layout/
│   │   │   └── activity_main.xml
│   │   └── values/
│   │       ├── colors.xml
│   │       ├── strings.xml
│   │       └── themes.xml
│   └── AndroidManifest.xml
├── build.gradle
└── proguard-rules.pro
```
