This is a placeholder. Replace with your actual app icon (ic_launcher.png).

For LinguaVibe, generate icons at:
https://romannurik.github.io/AndroidAssetStudio/icons-launcher.html

Required sizes:
- mipmap-mdpi: 48x48
- mipmap-hdpi: 72x72
- mipmap-xhdpi: 96x96
- mipmap-xxhdpi: 144x144
- mipmap-xxxhdpi: 192x192
