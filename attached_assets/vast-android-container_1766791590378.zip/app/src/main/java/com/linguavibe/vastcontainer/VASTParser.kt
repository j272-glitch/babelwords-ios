package com.linguavibe.vastcontainer

import android.util.Log
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader

// MARK: - Data Models

data class VASTData(
    var vastUrl: String,
    var mediaFiles: MutableList<VASTMediaFile> = mutableListOf(),
    var trackingEvents: MutableMap<String, MutableList<String>> = mutableMapOf(),
    var clickThrough: String? = null,
    var clickTracking: MutableList<String> = mutableListOf(),
    var duration: Double? = null,
    var wrapperUrl: String? = null,
    var adId: String? = null,
    var adTitle: String? = null
) {
    fun mergeTracking(wrapper: VASTData) {
        // Merge tracking events from wrapper
        for ((event, urls) in wrapper.trackingEvents) {
            trackingEvents.getOrPut(event) { mutableListOf() }.addAll(urls)
        }
        // Merge click tracking
        clickTracking.addAll(wrapper.clickTracking)
    }
}

data class VASTMediaFile(
    var url: String,
    var type: String,
    var width: Int? = null,
    var height: Int? = null,
    var bitrate: Int? = null,
    var delivery: String? = null
)

// MARK: - VAST Parser

class VASTParser {
    companion object {
        private const val TAG = "VASTParser"
    }

    fun parse(xmlString: String, vastUrl: String): VASTData? {
        val vastData = VASTData(vastUrl = vastUrl)

        try {
            val parser = Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(StringReader(xmlString))

            var eventType = parser.eventType
            var currentTag = ""
            var textContent = StringBuilder()

            // Parsing state
            var inAd = false
            var inWrapper = false
            var inLinear = false
            var inMediaFiles = false
            var inTrackingEvents = false
            var inVideoClicks = false

            var currentTrackingEvent = ""
            var currentMediaFile: VASTMediaFile? = null

            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        currentTag = parser.name
                        textContent = StringBuilder()

                        when (currentTag) {
                            "Ad" -> {
                                inAd = true
                                vastData.adId = parser.getAttributeValue(null, "id")
                            }
                            "Wrapper" -> inWrapper = true
                            "InLine" -> inWrapper = false
                            "Linear" -> inLinear = true
                            "MediaFiles" -> inMediaFiles = true
                            "MediaFile" -> {
                                if (inMediaFiles) {
                                    currentMediaFile = VASTMediaFile(
                                        url = "",
                                        type = parser.getAttributeValue(null, "type") ?: "video/mp4",
                                        width = parser.getAttributeValue(null, "width")?.toIntOrNull(),
                                        height = parser.getAttributeValue(null, "height")?.toIntOrNull(),
                                        bitrate = parser.getAttributeValue(null, "bitrate")?.toIntOrNull(),
                                        delivery = parser.getAttributeValue(null, "delivery")
                                    )
                                }
                            }
                            "TrackingEvents" -> inTrackingEvents = true
                            "Tracking" -> {
                                if (inTrackingEvents) {
                                    currentTrackingEvent = parser.getAttributeValue(null, "event") ?: ""
                                }
                            }
                            "VideoClicks" -> inVideoClicks = true
                        }
                    }

                    XmlPullParser.TEXT -> {
                        textContent.append(parser.text)
                    }

                    XmlPullParser.END_TAG -> {
                        val trimmedText = textContent.toString().trim()

                        when (parser.name) {
                            "Ad" -> inAd = false
                            "Linear" -> inLinear = false
                            "MediaFiles" -> inMediaFiles = false
                            "MediaFile" -> {
                                currentMediaFile?.let { mf ->
                                    if (trimmedText.isNotEmpty()) {
                                        mf.url = trimmedText
                                        vastData.mediaFiles.add(mf)
                                    }
                                }
                                currentMediaFile = null
                            }
                            "TrackingEvents" -> inTrackingEvents = false
                            "Tracking" -> {
                                if (inTrackingEvents && currentTrackingEvent.isNotEmpty() && trimmedText.isNotEmpty()) {
                                    vastData.trackingEvents
                                        .getOrPut(currentTrackingEvent) { mutableListOf() }
                                        .add(trimmedText)
                                }
                                currentTrackingEvent = ""
                            }
                            "VideoClicks" -> inVideoClicks = false
                            "ClickThrough" -> {
                                if (inVideoClicks && trimmedText.isNotEmpty()) {
                                    vastData.clickThrough = trimmedText
                                }
                            }
                            "ClickTracking" -> {
                                if (inVideoClicks && trimmedText.isNotEmpty()) {
                                    vastData.clickTracking.add(trimmedText)
                                }
                            }
                            "Duration" -> {
                                if (inLinear && trimmedText.isNotEmpty()) {
                                    vastData.duration = parseDuration(trimmedText)
                                }
                            }
                            "AdTitle" -> {
                                if (trimmedText.isNotEmpty()) {
                                    vastData.adTitle = trimmedText
                                }
                            }
                            "VASTAdTagURI", "AdTagURI" -> {
                                if (inWrapper && trimmedText.isNotEmpty()) {
                                    vastData.wrapperUrl = trimmedText
                                }
                            }
                            "Impression" -> {
                                if (trimmedText.isNotEmpty()) {
                                    vastData.trackingEvents
                                        .getOrPut("impression") { mutableListOf() }
                                        .add(trimmedText)
                                }
                            }
                            "Error" -> {
                                if (trimmedText.isNotEmpty()) {
                                    vastData.trackingEvents
                                        .getOrPut("error") { mutableListOf() }
                                        .add(trimmedText)
                                }
                            }
                        }
                        currentTag = ""
                    }
                }
                eventType = parser.next()
            }

            return vastData

        } catch (e: Exception) {
            Log.e(TAG, "Parse error", e)
            return null
        }
    }

    private fun parseDuration(durationString: String): Double? {
        // Format: HH:MM:SS or HH:MM:SS.mmm
        val parts = durationString.split(":")
        if (parts.size != 3) return null

        return try {
            val hours = parts[0].toDouble()
            val minutes = parts[1].toDouble()
            val seconds = parts[2].toDouble()
            hours * 3600 + minutes * 60 + seconds
        } catch (e: Exception) {
            null
        }
    }
}
