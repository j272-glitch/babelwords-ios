package com.linguavibe.vastcontainer

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : AppCompatActivity(), VASTAdManager.AdEventListener {

    private lateinit var webView: WebView
    private lateinit var adOverlay: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var skipButton: TextView
    private lateinit var skipCountdown: TextView

    private lateinit var vastAdManager: VASTAdManager
    private var exoPlayer: ExoPlayer? = null

    // Web app URL - change this to your app
    private val webAppUrl = "https://linguagt.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        webView = findViewById(R.id.webView)
        adOverlay = findViewById(R.id.adOverlay)
        playerView = findViewById(R.id.playerView)
        skipButton = findViewById(R.id.skipButton)
        skipCountdown = findViewById(R.id.skipCountdown)

        // Initialize VAST manager
        vastAdManager = VASTAdManager(this, this)

        // Setup WebView
        setupWebView()

        // Setup skip button
        skipButton.setOnClickListener {
            vastAdManager.skipAd()
        }

        // Load web app
        webView.loadUrl(webAppUrl)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(false)
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        // Add JavaScript bridge
        webView.addJavascriptInterface(AdBridge(), "AndroidAdBridge")

        // Inject bridge script when page loads
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectBridgeScript()
            }
        }
    }

    private fun injectBridgeScript() {
        val bridgeScript = """
            (function() {
                if (window.NativeAdBridge) return;
                
                window.NativeAdBridge = {
                    // Request a VAST ad
                    playVAST: function(vastUrl, options) {
                        AndroidAdBridge.playVAST(vastUrl, JSON.stringify(options || {}));
                    },
                    
                    // Check if native ads are available
                    isAvailable: function() {
                        return true;
                    },
                    
                    // Preload a VAST ad
                    preloadVAST: function(vastUrl) {
                        AndroidAdBridge.preloadVAST(vastUrl);
                    },
                    
                    // Cancel current ad
                    cancelAd: function() {
                        AndroidAdBridge.cancelAd();
                    },
                    
                    // Event callback (set by web app)
                    onAdEvent: null
                };
                
                // Notify web app that bridge is ready
                window.dispatchEvent(new Event('nativeAdBridgeReady'));
                
                console.log('[NativeAdBridge] Bridge initialized (Android)');
            })();
        """.trimIndent()

        webView.evaluateJavascript(bridgeScript, null)
    }

    // JavaScript bridge interface
    inner class AdBridge {
        @JavascriptInterface
        fun playVAST(vastUrl: String, optionsJson: String) {
            runOnUiThread {
                val options = try {
                    JSONObject(optionsJson)
                } catch (e: Exception) {
                    JSONObject()
                }

                val skipOffset = options.optInt("skipOffset", 5)

                lifecycleScope.launch {
                    vastAdManager.playVAST(vastUrl, skipOffset)
                }
            }
        }

        @JavascriptInterface
        fun preloadVAST(vastUrl: String) {
            lifecycleScope.launch {
                vastAdManager.preloadVAST(vastUrl)
            }
        }

        @JavascriptInterface
        fun cancelAd() {
            runOnUiThread {
                vastAdManager.cancelAd()
            }
        }
    }

    // VAST Ad Manager callbacks
    override fun onAdStarted(duration: Long) {
        runOnUiThread {
            // Show ad overlay
            adOverlay.visibility = View.VISIBLE

            // Setup ExoPlayer
            exoPlayer = ExoPlayer.Builder(this).build().also { player ->
                playerView.player = player
                player.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        if (state == Player.STATE_ENDED) {
                            vastAdManager.onAdCompleted()
                        }
                    }
                })
            }

            vastAdManager.setPlayer(exoPlayer!!)

            // Send callback to web app
            sendAdEvent("adStarted", mapOf("duration" to duration))
        }
    }

    override fun onAdProgress(currentTime: Long, totalDuration: Long, progress: Float) {
        runOnUiThread {
            sendAdEvent("adProgress", mapOf(
                "currentTime" to currentTime / 1000.0,
                "duration" to totalDuration / 1000.0,
                "progress" to progress
            ))
        }
    }

    override fun onSkipAvailable() {
        runOnUiThread {
            skipCountdown.visibility = View.GONE
            skipButton.visibility = View.VISIBLE
        }
    }

    override fun onSkipCountdown(seconds: Int) {
        runOnUiThread {
            skipButton.visibility = View.GONE
            skipCountdown.visibility = View.VISIBLE
            skipCountdown.text = "Skip in ${seconds}s"
        }
    }

    override fun onAdEnded(reason: String) {
        runOnUiThread {
            // Hide overlay
            adOverlay.visibility = View.GONE
            skipButton.visibility = View.GONE
            skipCountdown.visibility = View.GONE

            // Release player
            exoPlayer?.release()
            exoPlayer = null

            // Send callback to web app
            sendAdEvent("adEnded", mapOf("reason" to reason))
        }
    }

    override fun onAdError(error: String) {
        runOnUiThread {
            // Hide overlay
            adOverlay.visibility = View.GONE
            skipButton.visibility = View.GONE
            skipCountdown.visibility = View.GONE

            // Release player
            exoPlayer?.release()
            exoPlayer = null

            // Send callback to web app
            sendAdEvent("adError", mapOf("error" to error))
        }
    }

    override fun onAdPreloaded(url: String) {
        runOnUiThread {
            sendAdEvent("adPreloaded", mapOf("url" to url))
        }
    }

    private fun sendAdEvent(event: String, data: Map<String, Any>) {
        val jsonData = JSONObject(data).apply {
            put("event", event)
        }

        val script = """
            if (window.NativeAdBridge && window.NativeAdBridge.onAdEvent) {
                window.NativeAdBridge.onAdEvent($jsonData);
            }
        """.trimIndent()

        webView.evaluateJavascript(script, null)
    }

    override fun onBackPressed() {
        if (adOverlay.visibility == View.VISIBLE) {
            // Don't allow back during ad
            return
        }
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        exoPlayer?.release()
        webView.destroy()
    }
}
