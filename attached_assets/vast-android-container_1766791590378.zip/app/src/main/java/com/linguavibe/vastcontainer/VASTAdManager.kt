package com.linguavibe.vastcontainer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class VASTAdManager(
    private val context: Context,
    private val listener: AdEventListener
) {
    companion object {
        private const val TAG = "VASTAdManager"
    }

    interface AdEventListener {
        fun onAdStarted(duration: Long)
        fun onAdProgress(currentTime: Long, totalDuration: Long, progress: Float)
        fun onSkipAvailable()
        fun onSkipCountdown(seconds: Int)
        fun onAdEnded(reason: String)
        fun onAdError(error: String)
        fun onAdPreloaded(url: String)
    }

    // HTTP client (native - bypasses WebView)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Parser
    private val vastParser = VASTParser()

    // Player reference
    private var player: ExoPlayer? = null

    // Current ad state
    private var currentVAST: VASTData? = null
    private var preloadedVAST: VASTData? = null
    private var skipOffsetSeconds = 5
    private var canSkip = false

    // Tracking state
    private var hasFiredImpression = false
    private val firedQuartiles = mutableSetOf<String>()

    // Progress handler
    private val handler = Handler(Looper.getMainLooper())
    private var progressRunnable: Runnable? = null

    fun setPlayer(exoPlayer: ExoPlayer) {
        this.player = exoPlayer
    }

    suspend fun playVAST(vastUrl: String, skipOffset: Int = 5) {
        skipOffsetSeconds = skipOffset

        // Check if preloaded
        preloadedVAST?.let { preloaded ->
            if (preloaded.vastUrl == vastUrl) {
                playParsedVAST(preloaded)
                preloadedVAST = null
                return
            }
        }

        // Fetch and play
        try {
            val vastData = fetchVAST(vastUrl)
            if (vastData != null) {
                playParsedVAST(vastData)
            } else {
                listener.onAdError("Failed to parse VAST")
            }
        } catch (e: Exception) {
            Log.e(TAG, "VAST fetch error", e)
            listener.onAdError(e.message ?: "Unknown error")
        }
    }

    suspend fun preloadVAST(vastUrl: String) {
        try {
            val vastData = fetchVAST(vastUrl)
            if (vastData != null) {
                preloadedVAST = vastData
                listener.onAdPreloaded(vastUrl)
            }
        } catch (e: Exception) {
            Log.e(TAG, "VAST preload error", e)
        }
    }

    fun skipAd() {
        if (!canSkip) return
        fireTracking("skip")
        stopAd("skipped")
    }

    fun cancelAd() {
        stopAd("cancelled")
    }

    fun onAdCompleted() {
        fireTracking("complete")
        stopAd("completed")
    }

    // MARK: - VAST Fetching (Native OkHttp - No WebView)

    private suspend fun fetchVAST(url: String): VASTData? = withContext(Dispatchers.IO) {
        Log.d(TAG, "Fetching VAST: $url")

        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android) LinguaVibe/1.0")
            .build()

        try {
            val response = httpClient.newCall(request).execute()

            if (!response.isSuccessful) {
                Log.e(TAG, "VAST fetch failed: ${response.code}")
                return@withContext null
            }

            val body = response.body?.string() ?: return@withContext null
            val vastData = vastParser.parse(body, url)

            // Handle wrapper (redirect)
            vastData?.wrapperUrl?.let { wrapperUrl ->
                Log.d(TAG, "Following wrapper: $wrapperUrl")
                val wrappedData = fetchVAST(wrapperUrl)
                wrappedData?.mergeTracking(vastData)
                return@withContext wrappedData
            }

            return@withContext vastData
        } catch (e: Exception) {
            Log.e(TAG, "VAST fetch exception", e)
            return@withContext null
        }
    }

    // MARK: - Playback

    private fun playParsedVAST(vastData: VASTData) {
        val mediaUrl = selectBestMediaFile(vastData.mediaFiles)
        if (mediaUrl == null) {
            Log.e(TAG, "No playable media file found")
            listener.onAdError("No playable media")
            return
        }

        Log.d(TAG, "Playing media: $mediaUrl")

        currentVAST = vastData
        hasFiredImpression = false
        firedQuartiles.clear()
        canSkip = false

        // Setup player
        player?.let { exo ->
            val mediaItem = MediaItem.fromUri(mediaUrl)
            exo.setMediaItem(mediaItem)
            exo.prepare()
            exo.playWhenReady = true
        }

        // Start progress tracking
        startProgressTracking()

        // Fire impression
        fireTracking("impression")
        fireTracking("start")
        hasFiredImpression = true

        val duration = vastData.duration?.times(1000)?.toLong() ?: 0
        listener.onAdStarted(duration)
    }

    private fun selectBestMediaFile(mediaFiles: List<VASTMediaFile>): String? {
        // Prefer MP4
        val mp4Files = mediaFiles.filter { it.type.contains("mp4") }
        val candidates = if (mp4Files.isNotEmpty()) mp4Files else mediaFiles

        if (candidates.isEmpty()) return null

        // Sort by bitrate, pick middle quality
        val sorted = candidates.sortedBy { it.bitrate ?: 0 }
        return sorted[sorted.size / 2].url
    }

    private fun startProgressTracking() {
        progressRunnable = object : Runnable {
            override fun run() {
                player?.let { exo ->
                    if (exo.isPlaying) {
                        handleTimeUpdate(exo.currentPosition, exo.duration)
                    }
                    handler.postDelayed(this, 500)
                }
            }
        }
        handler.post(progressRunnable!!)
    }

    private fun stopProgressTracking() {
        progressRunnable?.let { handler.removeCallbacks(it) }
        progressRunnable = null
    }

    private fun handleTimeUpdate(currentMs: Long, durationMs: Long) {
        if (durationMs <= 0) return

        val currentSeconds = currentMs / 1000
        val progress = currentMs.toFloat() / durationMs.toFloat()

        // Update skip state
        if (!canSkip) {
            val remaining = skipOffsetSeconds - currentSeconds.toInt()
            if (remaining <= 0) {
                canSkip = true
                listener.onSkipAvailable()
            } else {
                listener.onSkipCountdown(remaining)
            }
        }

        // Fire quartile events
        if (progress >= 0.25f && "firstQuartile" !in firedQuartiles) {
            fireTracking("firstQuartile")
            firedQuartiles.add("firstQuartile")
        }
        if (progress >= 0.5f && "midpoint" !in firedQuartiles) {
            fireTracking("midpoint")
            firedQuartiles.add("midpoint")
        }
        if (progress >= 0.75f && "thirdQuartile" !in firedQuartiles) {
            fireTracking("thirdQuartile")
            firedQuartiles.add("thirdQuartile")
        }

        // Notify listener
        listener.onAdProgress(currentMs, durationMs, progress)
    }

    private fun stopAd(reason: String) {
        stopProgressTracking()

        player?.let { exo ->
            exo.stop()
            exo.clearMediaItems()
        }

        currentVAST = null
        canSkip = false

        listener.onAdEnded(reason)
    }

    // MARK: - Tracking (Native OkHttp - No WebView)

    private fun fireTracking(event: String) {
        val urls = currentVAST?.trackingEvents?.get(event) ?: return

        Log.d(TAG, "Firing tracking: $event (${urls.size} URLs)")

        for (urlString in urls) {
            Thread {
                try {
                    val request = Request.Builder()
                        .url(urlString)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android) LinguaVibe/1.0")
                        .build()

                    httpClient.newCall(request).execute().close()
                } catch (e: Exception) {
                    Log.e(TAG, "Tracking error for $event", e)
                }
            }.start()
        }
    }
}
