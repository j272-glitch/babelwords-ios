# Add project specific ProGuard rules here.

# Keep OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep class okio.** { *; }

# Keep ExoPlayer
-keep class androidx.media3.** { *; }

# Keep JavaScript interface
-keepclassmembers class com.linguavibe.vastcontainer.MainActivity$AdBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep data classes
-keep class com.linguavibe.vastcontainer.VASTData { *; }
-keep class com.linguavibe.vastcontainer.VASTMediaFile { *; }
